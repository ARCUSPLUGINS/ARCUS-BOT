---
description: 7 commands
---

# 🪙 Economy

| Command                                | Slash              | Description                           |
| -------------------------------------- | ------------------ | ------------------------------------- |
| **!bank balance**                      | **/bank balance**  | check your coin balance               |
| **!bank deposit \<amount>**            | **/bank deposit**  | deposit coins to your bank account    |
| **!bank withdraw \<amount>**           | **/bank withdraw** | withdraw coins from your bank account |
| **!bank transfer \<member> \<amount>** | **/bank transfer** | transfer coins to other user          |
| **!beg**                               | **/beg**           | beg from someone                      |
| **!daily**                             | **/daily**         | receive a daily bonus                 |
| **!gamble \<amount>**                  | **/gamble**        | try your luck by gambling             |
